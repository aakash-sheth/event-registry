/**
 * TypeScript schema for Living Poster Invitation configuration
 */

export interface BackgroundImage {
  type: 'image'
  src: string
  parallax?: boolean
  // Background adjustment options
  fitMode?: 'cover' | 'contain' | 'picture-in-picture' | 'blur-fill'
  backgroundColor?: string // Extracted or user-selected color
  position?: 'center' | 'top' | 'bottom' | 'left' | 'right'
  focusPoint?: { x: number; y: number } // 0-100, center of important content for responsive positioning
  scale?: number // 0.5 to 2.0
  originalAspectRatio?: { width: number; height: number }
  dominantColors?: string[] // Extracted dominant colors
}

// Tile-based structure
export type TileType = 'title' | 'image' | 'greeting-card' | 'timer' | 'event-details' | 'description' | 'feature-buttons' | 'footer' | 'event-carousel'

export interface TitleTileSettings {
  text: string
  font?: string // Font family from FONT_OPTIONS
  color?: string // Hex color
  size?: 'small' | 'medium' | 'large' | 'xlarge' // Title size option (preset)
  // Optional second line (e.g. "Request the pleasure of your company…")
  subtitle?: string
  subtitleFont?: string
  subtitleColor?: string
  subtitleSize?: 'small' | 'medium' | 'large'
  overlayPosition?: { x: number; y: number } // % position when overlaying on image tile
}

export interface TextOverlay {
  id: string
  text: string
  x: number         // % from left edge of 9:16 container (card designer coordinate)
  y: number         // % from top edge of 9:16 container (card designer coordinate)
  width: number     // % of container width
  height?: number | null  // % of container height, null/undefined = auto
  fontFamily: string
  fontSize: number  // px
  color: string
  bold: boolean
  italic: boolean
  underline: boolean
  strikethrough: boolean
  textAlign: 'left' | 'center' | 'right'
  verticalAlign?: 'top' | 'middle' | 'bottom'
}

export interface ImageTileSettings {
  src?: string // Image URL or data URL
  fitMode?: 'fit-to-screen' | 'full-image'
  backgroundColor?: string // Background color if image doesn't fill
  backgroundGradient?: string // CSS gradient string e.g. 'linear-gradient(135deg, #fce4ec, #f48fb1)' — used when no src image is set
  blur?: number // 0-100
  coverPosition?: 'center' | 'top' | 'bottom' | 'left' | 'right' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | { x: number; y: number } // Position for cover image mode (x, y are 0-100 percentages)
  // Shape and frame (for sleek invite look)
  shape?: 'rectangle' | 'circle' | 'rounded'
  frameStyle?: 'none' | 'single' | 'double'
  frameColor?: string // Hex color for frame border
  frameWidth?: number // Pixels
  // Text overlays from card designer (stored with 9:16 coordinate system)
  textOverlays?: TextOverlay[]
}

export interface GreetingCardTileSettings {
  src?: string                  // Image URL or data URL
  backgroundGradient?: string   // CSS gradient when no image e.g. 'linear-gradient(135deg, #fce4ec, #f48fb1)'
  textOverlays?: TextOverlay[]  // Positioned text boxes from the card designer (9:16 coordinate system)
  // How the source image fills the 9:16 card frame.
  //   'cover'   (default) — fills the frame and crops sides/top to fit
  //   'contain' — shows the entire image, may letterbox if aspect mismatches 9:16
  // Auto-generated layouts use 'contain' so user-uploaded cards aren't cropped.
  imageFit?: 'cover' | 'contain'
}

export interface TimerTileSettings {
  enabled: boolean
  format: 'circle' | 'inline' // Circle format: (12) Days (20) Hours | Inline: Days:Hours:Mins
  circleColor?: string // Color for circles (hex color or 'transparent')
  textColor?: string // Color for timer text (hex color)
}

export interface EventDetailsTileSettings {
  location: string // Display text for location (flexible, e.g., "Grand Ballroom", "Beachside Venue")
  date: string // ISO date string
  time?: string // Time string (e.g., "18:00")
  dressCode?: string
  mapUrl?: string // Map location - accepts address text or Google Maps URL (auto-validated and verified)
  locationVerified?: boolean // Auto-set by system based on map location validation (true if valid, false if invalid)
  coordinates?: {
    lat: number
    lng: number
  } // Optional precise coordinates (auto-verifies when provided)
  showMap?: boolean // Option to display embedded map (only works if mapUrl is provided and valid and location is verified)
  mapZoom?: number // Zoom level for embedded map (11-20: 11-15 for city/area view, 16-20 for street view, default: 15)
  fontColor?: string // Font color for event details text (hex color, e.g., "#000000")
  buttonColor?: string // Hex color for Save the Date button (e.g., "#1F2937")
  // Date block layout: single-line (default) or day-prominent (large day number, smaller weekday/month/year/time)
  dateLayout?: 'single-line' | 'day-prominent'
  // Border styling options
  borderStyle?: 'elegant' | 'minimal' | 'ornate' | 'modern' | 'classic' | 'vintage' | 'none'
  borderColor?: string // Hex color for borders (default: based on borderStyle)
  borderWidth?: number // 1-4 pixels (default: 1)
  decorativeSymbol?: string // Custom symbol (❦, ✿, ✤, ✦, •, —, or empty)
  backgroundColor?: string // Background color for the tile (default: transparent or gray-50)
  borderRadius?: number // 0-24 pixels (default: 0 for preview, 4 for non-preview)
}

export interface DescriptionTileSettings {
  content: string // Rich text/markdown content
  fontColor?: string // Hex color; use for contrast on dark themes
}

export interface FeatureButtonsTileSettings {
  buttonColor?: string // Hex color for buttons
  rsvpLabel?: string // Custom label for RSVP button (default: "RSVP")
  registryLabel?: string // Custom label for Registry button (default: "Registry")
}

export interface FooterTileSettings {
  text: string
  fontColor?: string // Hex color; use theme fg on dark backgrounds for contrast
}

export interface EventCarouselTileSettings {
  showFields: {
    image?: boolean
    title?: boolean
    dateTime?: boolean
    location?: boolean
    cta?: boolean
  }
  // Slideshow controls
  autoPlay?: boolean // Default: true
  autoPlayInterval?: number // Default: 5000, range: 3000-10000
  showArrows?: boolean // Default: true
  showDots?: boolean // Default: true
  // Card styling presets
  cardStyle?: 'minimal' | 'elegant' | 'modern' | 'classic' // Default: 'elegant'
  cardLayout?: 'full-width' | 'centered' | 'grid' // Default: 'centered'
  cardSpacing?: 'tight' | 'normal' | 'spacious' // Default: 'normal'
  // Card customization
  cardBackgroundColor?: string // Hex color, default: '#ffffff'
  cardBorderRadius?: number // 0-24, default: 12
  cardShadow?: 'none' | 'sm' | 'md' | 'lg' | 'xl' // Default: 'md'
  cardBorderWidth?: number // 0-4, default: 0
  cardBorderColor?: string // Hex color
  cardBorderStyle?: 'solid' | 'dashed' // Default: 'solid'
  cardPadding?: 'tight' | 'normal' | 'spacious' // Default: 'normal'
  // Image settings
  imageHeight?: 'small' | 'medium' | 'large' | 'full' // Default: 'medium'
  imageAspectRatio?: '16:9' | '4:3' | '1:1' | 'auto' // Default: '16:9'
  // Global styling for sub-events (applies uniformly to all sub-events)
  subEventTitleStyling?: {
    font?: string // Font family from FONT_OPTIONS
    color?: string // Hex color
    size?: 'small' | 'medium' | 'large' | 'xlarge'
  }
  subEventDetailsStyling?: {
    fontColor?: string // Hex color for date/time and location text
  }
}

export type TextureType =
  | 'none'
  | 'paper-grain'
  | 'linen'
  | 'canvas'
  | 'parchment'
  | 'vintage-paper'
  | 'silk'
  | 'marble'

export interface TextureSettings {
  type: TextureType
  intensity?: number // 0-100, default 20
  imageUrl?: string // Optional texture image (e.g. marble photo, watercolor)
  textureBlend?: 'overlay' | 'replace' // When imageUrl set: overlay on background, or replace CSS texture
}

export interface LinkMetadata {
  title?: string // Custom title for link previews (WhatsApp, Facebook, Twitter) - overrides auto-generated
  description?: string // Custom description for link previews - overrides auto-generated
  image?: string // Custom image URL for link previews - overrides auto-generated (recommended: 1200x630px)
  previewImageOriginal?: string // Original uploaded image URL for re-editing framing
  previewImageCrop?: { x: number; y: number; width: number; height: number } // Crop rectangle in original image coordinates
  previewImageCropAspectRatio?: number // Aspect ratio used when cropping (e.g., 1200/630)
  previewImageSource?: 'upload' | 'greeting-card' | 'image-tile' // Which source drives the OG image
  previewTitleSource?: 'auto' | 'custom' // Whether to use auto-generated or custom title
  previewDescriptionSource?: 'auto' | 'custom' // Whether to use auto-generated or custom description
}

export type RsvpFieldType = 'text' | 'number' | 'select' | 'radio' | 'checkbox'

export interface RsvpFieldOption {
  label: string
  value: string
}

export interface RsvpSystemFieldConfig {
  enabled: boolean
  label?: string
  helpText?: string
}

export interface RsvpCustomFieldConfig {
  /** Normalized guest custom field key (must exist in guest management). */
  key: string
  enabled: boolean
  required?: boolean
  label?: string
  helpText?: string
  type: RsvpFieldType
  options?: RsvpFieldOption[] // required for select/radio
}

export interface RsvpFormConfig {
  version: 1
  systemFields?: {
    notes?: RsvpSystemFieldConfig
    email?: RsvpSystemFieldConfig
    guests_count?: RsvpSystemFieldConfig
  }
  customFields?: RsvpCustomFieldConfig[]
  /** If true, answers are copied into Guest.custom_fields when the RSVP matches a guest. */
  writeBackToGuest?: boolean
}

export type TileSettings =
  | TitleTileSettings
  | ImageTileSettings
  | GreetingCardTileSettings
  | TimerTileSettings
  | EventDetailsTileSettings
  | DescriptionTileSettings
  | FeatureButtonsTileSettings
  | FooterTileSettings
  | EventCarouselTileSettings

export interface Tile {
  id: string
  type: TileType
  enabled: boolean
  order: number // Saved order (snapshot when save button clicked) - used by invite page
  previewOrder?: number // Real-time order for mobile preview (not saved to backend)
  settings: TileSettings
  overlayTargetId?: string // If set, this title tile overlays on top of the target tile (image)
}

export interface InviteConfig {
  themeId: string
  // Custom overrides (optional - if not set, uses theme defaults)
  customColors?: {
    backgroundColor?: string // Overrides theme.palette.bg
    fontColor?: string // Overrides theme.palette.fg
    primaryColor?: string // Overrides theme.palette.primary
    mutedColor?: string // Overrides theme.palette.muted
  }
  customFonts?: {
    titleFont?: string // Overrides theme.fonts.title
    bodyFont?: string // Overrides theme.fonts.body
  }
  // Background texture (CSS-based)
  texture?: TextureSettings
  // Page border settings
  pageBorder?: {
    enabled?: boolean // Enable/disable page border (default: false)
    style?: 'solid' | 'dotted' | 'dashed' | 'double' | 'groove' | 'ridge' | 'inset' | 'outset' | 'intaglio' // Border style
    color?: string // Hex color for border (default: '#D1D5DB')
    width?: number // Border width in pixels (default: 2)
  }
  // Full-page frame image (ornate border/frame overlay, e.g. SVG or PNG with transparency)
  pageFrame?: {
    imageUrl?: string
  }
  // Corner decoration image URLs (optional flourishes in each corner)
  cornerDecorations?: {
    topLeft?: string
    topRight?: string
    bottomLeft?: string
    bottomRight?: string
  }
  // Animation settings
  animations?: {
    envelope?: boolean // Enable/disable envelope opening animation (default: true)
    /** When true, each tile opacity follows viewport: fades in top/bottom 10px bands while scrolling. */
    tileViewportFade?: boolean
    /** Pixel inset from top and bottom of viewport for the fade band (default 10). */
    tileViewportFadeInsetPx?: number
  }
  // Link preview metadata (Open Graph, Twitter Cards, WhatsApp)
  linkMetadata?: LinkMetadata
  // RSVP form configuration (host-managed)
  rsvpForm?: RsvpFormConfig
  // New tile-based structure
  tiles?: Tile[]
  // When true, design page must not merge in missing tile types (preserves template-defined tile set)
  tileSetComplete?: boolean
  // Global spacing between tiles
  spacing?: 'tight' | 'normal' | 'spacious'
  // Legacy structure (for backward compatibility)
  hero?: {
    background?: BackgroundImage | {
      type: 'video' | 'gradient'
      src?: string
      gradientFrom?: string
      gradientTo?: string
      parallax?: boolean
    }
    eventType?: string
    title: string
    subtitle?: string
    showTimer: boolean
    eventDate?: string // ISO string
    buttons: Array<{
      label: 'Save the Date' | 'RSVP' | 'Registry'
      action: 'calendar' | 'rsvp' | 'registry'
      href?: string
    }>
  }
  descriptionMarkdown?: string
  location?: {
    name?: string
    address?: string
    lat?: number
    lng?: number
  }
}

export interface InvitePage {
  id: number
  event: number
  event_slug: string
  slug: string
  background_url: string
  config: InviteConfig
  is_published: boolean
  show_branding?: boolean
  rsvp_count?: number
  created_at: string
  updated_at: string
}

